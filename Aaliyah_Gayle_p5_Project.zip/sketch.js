function setup() {
  createCanvas(400, 400);
}

function draw() {
 
  background(30,100,250);
  translate (0,0 ) 
ellipse(100, 100, 100, 100); 
  fill(0)
ellipse(300, 100, 100, 100)  
  triangle(150, 200, 150, 160, 200, 180);
  arc(200, 290, 110, 100, 0, PI + QUARTER_PI, CHORD);
 let mouseEye = map( mouseX, 0, width, -20 ,20, 1); 
  push();
  fill(30, 100,250)
  ellipse(100 + mouseEye, 100, 50, 50)
  ellipse (300 + mouseEye, 100, 50, 50)
  pop();  
 
console.log(mouseX + "," + mouseY)


}